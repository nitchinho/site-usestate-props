import "./style.css";

export default function CardInformacoes({ tipoAnimal, informacaoAnimal }) {
  return (
    <div className="CardInformacao">
      <h3>Informação sobre o {tipoAnimal}</h3>
      <p>{informacaoAnimal}</p>
    </div>
  );
}